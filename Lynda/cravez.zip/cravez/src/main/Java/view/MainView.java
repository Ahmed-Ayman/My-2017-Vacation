package Java.view;

import Java.utils.DBHandler.DBManager;
import Java.utils.service.MainService;
import javafx.application.Application;
import javafx.stage.Stage;

import java.sql.SQLException;

public class MainView extends Application {
    public final static String TAG = MainView.class.getName();
    /*
    @Override
    public void start(Stage primaryStage) throws Exception{
       // Parent root = FXMLLoader.load(getClass().getResource("../../resources/layouts/sample.fxml"));

        //
            final Label response = new Label("");
            Label title = new Label("Services Manager!");
            title.setFont(Font.font("Arial", FontWeight.BOLD, 20));
            title.setTextFill(Color.CADETBLUE);
            FlowPane root = new FlowPane();
            root.setAlignment(Pos.CENTER);
            Scene scene = new Scene(root, 450, 450);
            final ObservableList<Contact> contactList = FXCollections.observableArrayList(
                    new Contact("cluster service", "running"),
                    new Contact("cluster service", "running"),
                    new Contact("cluster service", "running"),
                    new Contact("cluster service", "running")
                    );

            TableView<Contact> tvContacts;

            tvContacts = new TableView<Contact>(contactList);

            TableColumn<Contact, String> fName = new TableColumn<Contact,String>("First Name");
            fName.setCellValueFactory(new PropertyValueFactory<Contact,String>("firstName"));
            tvContacts.getColumns().add(fName);

            TableColumn<Contact, String> lName = new TableColumn<Contact,String>("Last Name");
            lName.setCellValueFactory(new PropertyValueFactory<Contact,String>("lastName"));
            tvContacts.getColumns().add(lName);

            TableColumn<Contact, String> cell = new TableColumn<Contact,String>("Cell Phone Number");
            cell.setCellValueFactory(new PropertyValueFactory<Contact,String>("cellPhone"));
            tvContacts.getColumns().add(cell);

            tvContacts.setPrefWidth(300);
            tvContacts.setPrefHeight(300);

            TableView.TableViewSelectionModel<Contact> tvSelContact =
                    tvContacts.getSelectionModel();

            tvSelContact.selectedIndexProperty().addListener(new ChangeListener<Number>()
            {
                public void changed(ObservableValue<? extends Number> changed,
                                    Number oldVal, Number newVal) {
                    int index =  newVal.intValue();
                    response.setText("The cell number for the contact selected is "
                            +contactList.get(index).getCellPhone());
                }
            });

            response.setFont(Font.font("Arial", 14));
            root.getChildren().addAll(title,tvContacts, response);
            //
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }
*/
    public static void main(String[] args) {
        //connect to the database.
        try {
            DBManager.connect();
            DBManager.getMainTableAttrs(MainService.MAINTABLE);
        } catch (SQLException e) {
            System.err.print(TAG + " : "+e);
        }

        //launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

    }
}
