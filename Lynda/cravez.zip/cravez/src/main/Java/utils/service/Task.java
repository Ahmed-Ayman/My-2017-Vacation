/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Java.utils.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 *
 * @author m.abdo
 */
public abstract class Task extends Thread {

    protected Date startTime, endTime;
    protected int dataSet;
    protected int status;
    protected String tableName;
    
    public Task(int dataSet , String tableName) {
        this.dataSet = dataSet;
        this.tableName = tableName;
        
    }

    @Override
    public void run() {
        Calendar cal = Calendar.getInstance(); 
        this.startTime = cal.getTime();
        this.status = Status.INPROGRESS;
        execute();
    }

    private void execute() {
        List<Object> objects = runAlgorithm();
        writeResult(objects);
    }

    protected abstract List<Object> runAlgorithm();

    protected abstract void writeResult(List<Object> objects);
    
}
