/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Java.utils.service;

/**
 *
 * @author m.abdo
 */
public final class Status {
    public final static int INPROGRESS = 0;
    public final static int PROCESSED = 1;
    public final static int CRASHED = 2;
}
