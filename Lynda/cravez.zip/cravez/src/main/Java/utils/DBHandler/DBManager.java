package Java.utils.DBHandler;

import java.sql.*;

/**
 * Created by ahmed-ayman on 8/16/17.
 */
public class DBManager {

    /**
     *  Note : Don't forget to add the Oracle driver in your project structure.
     */
    private static final String USERNAME = "CRAVEZ_ADMIN";
    private static final String PASSWORD = "admin";
    private static final String CONN_STRING =
            "jdbc:oracle:thin:@192.168.1.13:1521:orcl";
    static  Connection conn = null;

    public static void connect() throws SQLException {
        try {
            conn = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
            System.out.println("Connected!");
        } catch (SQLException e) {
            System.out.println("EROR!");
            System.err.println(e);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }


    public static void  getMainTableAttrs() {
        String tName= "MAIN_TABLE";
            String query= "SELECT  * from "+tName;
        Statement statement = null;
        try {

            statement = conn.createStatement();
            ResultSet rs = statement.executeQuery(query);
            while (rs.next()) {
                String viewName = rs.getString("VIEW_NAME");
                String dataSeq = rs.getString("DATA_SEQ");
                System.out.println(dataSeq +"\t"+viewName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
